package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B2cEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(B2cEcommerceApplication.class, args);
	}
}
